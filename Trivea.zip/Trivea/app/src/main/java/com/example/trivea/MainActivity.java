package com.example.trivea;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.example.trivea.controller.AppController;
import com.example.trivea.data.AnswerlistAsyncResponse;
import com.example.trivea.data.Repository;
import com.example.trivea.databinding.ActivityMainBinding;
import com.example.trivea.model.Question;
import com.example.trivea.model.Score;
import com.example.trivea.util.Prefs;

import org.json.JSONArray;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private int currentQuestionIndex = 0;
    private int scores = 0;
    List<Question> questions;
    private Score score;
    private Prefs prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        score = new Score();
        prefs = new Prefs(MainActivity.this);

        binding.scoreTextView.setText(MessageFormat.format("Current Score: {0}", String.valueOf(score.getScore())));

        // Retrieve the last state
        currentQuestionIndex = prefs.getState();
        binding.higestScoreTextView.setText(MessageFormat.format("Highest Score: {0}", String.valueOf(prefs.getHighestScore())));

        questions = new Repository().getQuestions(questionArrayList -> {
            binding.questionTextView.setText(questionArrayList.get(currentQuestionIndex).getAnswer());
            updateCounter(questionArrayList);
        });

        binding.buttonPrev.setOnClickListener(v -> {
            getPrevQues();
        });
        binding.buttonNext.setOnClickListener(v -> {
            getNextQues();
        });
        binding.buttonFalse.setOnClickListener(v -> {
            checkAnswer(false);
            updateQuestion();

        });
        binding.buttonTrue.setOnClickListener(v -> {
            checkAnswer(true);
            updateQuestion();
        });
    }

    private void getNextQues() {
        currentQuestionIndex = (currentQuestionIndex + 1) % questions.size();
        updateQuestion();
    }
    private  void getPrevQues() {
        currentQuestionIndex = (currentQuestionIndex - 1) % questions.size();
        updateQuestion();
    }

    private void updateCounter(ArrayList<Question> questionArrayList) {
        binding.textViewOutOf.setText(String.format(getString(R.string.textFormatted), currentQuestionIndex+1, questionArrayList.size()+1));
    }

    private void updateQuestion() {
        String question = questions.get(currentQuestionIndex).getAnswer();
        binding.questionTextView.setText(question);
        updateCounter((ArrayList<Question>) questions);
    }
    private void checkAnswer(boolean userAnswer) {
        boolean answer = questions.get(currentQuestionIndex).isAnswerTrue();
        String text = "Answer chosen is ";
        if(answer == userAnswer) {
            text += "correct";
            addPoints();
            fadeAnimation();
        } else{
            text += "wrong";
            deductPoints();
            shakeAnimation();
        }
        binding.scoreTextView.setText(MessageFormat.format("Current Score: {0}", String.valueOf(score.getScore())));
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private void addPoints() {
        scores += 10;
        score.setScore(scores);
    }
    private void deductPoints() {
        if(scores-5 >= 0) scores -= 5;
        score.setScore(scores);
    }

    private void fadeAnimation() {
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(300);
        alphaAnimation.setRepeatCount(1);
        alphaAnimation.setRepeatMode(Animation.REVERSE);

        binding.cardView.setAnimation(alphaAnimation);
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                binding.questionTextView.setTextColor(Color.GREEN);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                binding.questionTextView.setTextColor(Color.WHITE);
                getNextQues();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
    private void shakeAnimation() {
        Animation shake = AnimationUtils.loadAnimation(MainActivity.this, R.anim.shake_animation);
        binding.cardView.setAnimation(shake);
        shake.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                binding.questionTextView.setTextColor(Color.RED);
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                binding.questionTextView.setTextColor(Color.WHITE);
                getNextQues();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    @Override
    protected void onPause() {
        prefs.saveHighestScore(score.getScore());
        prefs.setState(currentQuestionIndex, questions.size());
        super.onPause();

    }
}