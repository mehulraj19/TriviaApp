package com.example.trivea.data;

import com.example.trivea.model.Question;

import java.util.ArrayList;

public interface AnswerlistAsyncResponse {
    void processFinished(ArrayList<Question> questionArrayList);
}
