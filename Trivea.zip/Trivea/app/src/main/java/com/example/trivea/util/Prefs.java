package com.example.trivea.util;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private SharedPreferences preferences;

    public Prefs(Activity context) {
        this.preferences = context.getPreferences(Context.MODE_PRIVATE);
    }
    public void saveHighestScore(int currentScore) {
        int lastScore = preferences.getInt("highestScore", 0);
        if(currentScore > lastScore) {
            preferences.edit().putInt("highestScore", currentScore).apply();
        }
    }
    public int getHighestScore() {
        return preferences.getInt("highestScore", 0);
    }
    public void setState(int index, int totalQues) {
        if(totalQues == index){
            preferences.edit().putInt("triviaState", 0).apply();
        }
        preferences.edit().putInt("triviaState", index).apply();
    }
    public int getState() {
        return preferences.getInt("triviaState", 0);
    }
}
